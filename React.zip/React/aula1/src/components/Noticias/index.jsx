import "./index.css";

const Noticias = ({ children }) => {
    return (
        <div className="noticias">
            {children}
        </div>
    );
}

export default Noticias;